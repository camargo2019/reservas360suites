<?php
//Gabriel CMR - Desenvolvimentos
//Autoload

	require __DIR__."/../vendor/autoload.php";

	require __DIR__."/config.php";

	require __DIR__."/conect.php";

	require __DIR__."/class.api.beds24.php";

	require __DIR__."/class.pagseguro.php";

	require __DIR__."/class.functions.php";