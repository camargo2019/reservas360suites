<div class="footer">

	<div class="developer"> Desenvolvido com <i class="fas fa-heart"></i> por <a href="http://salvianosolucoes.com.br/">Salviano Soluções IT</a> 
		<div class="copyright">Copyright © Todos os direitos reservados a 360Suites. <?=date('Y');?></div>
	</div>


	<div class="pagsegurofooter">
		<img src="//assets.pagseguro.com.br/ps-integration-assets/banners/pagamento/todos_animado_550_50.gif" alt="Logotipos de meios de pagamento do PagSeguro" title="Este site aceita pagamentos com as principais bandeiras e bancos, saldo em conta PagSeguro e boleto.">
	</div>
</div>