<div class="empty-state-message-content">
	<div class="empty-state-message-title eva-3-h4 -eva-3-tc-gray-0">
	Recalculando! Parece que o sinal do GPS foi perdido.
</div>
<p class="empty-state-message-description eva-3-p -eva-3-tc-gray-2">
Não foi possível encontrar o que você estava buscando. Volte ao início para continuar planejando a sua viagem. O destino que você tanto quer está mais perto do que você imagina.</p>
<div class="empty-state-message-button">
	<a href="/" class="eva-3-btn -md -primary"><em class="btn-text">Ir para o Início</em></a>
</div>
</div>